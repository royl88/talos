# coding=utf-8

TEMPLATE = u'''# Include the license file
include LICENSE
include README.md
include VERSION
include requirements.txt

# Include the data files
'''