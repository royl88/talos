# coding=utf-8

TEMPLATE = u'''${version}
'''