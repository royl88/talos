# coding=utf-8

TEMPLATE = u'''Generic single-database configuration.
'''