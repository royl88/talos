# coding=utf-8

TEMPLATE = u'''# Project Translate.
# Copyright (C) 2017 AutoGen
# AutoGen <AutoGen@sample.com>, 2017.
#
msgid ""
msgstr ""
"Project-Id-Version: 1.0\n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: 2017-07-24 10:36+0800\n"
"PO-Revision-Date: 2017-08-21 15:22+0800\n"
"Last-Translator: Roy <wjjroy@outlook.com>\n"
"Language-Team: English <wjjroy@outlook.com>\n"
"Language: en\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: 8bit\n"
"Generated-By: pygettext.py 1.5\n"
"X-Generator: Poedit 2.0.3\n"
'''
