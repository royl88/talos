# coding=utf-8

TEMPLATE = u'''# coding=utf-8

from __future__ import absolute_import

from ${pkg_name}.apps.${app_name} import route
'''
