# coding=utf-8

TEMPLATE = u'''${sys_default_coding}

from __future__ import absolute_import

from ${pkg_name}.apps.${app_name} import route
'''
