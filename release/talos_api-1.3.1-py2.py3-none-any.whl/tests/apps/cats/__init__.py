# coding=utf-8

from tests.apps.cats import route
