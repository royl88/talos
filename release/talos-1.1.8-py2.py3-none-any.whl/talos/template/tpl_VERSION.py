# coding=utf-8

TEMPLATE = u'''1.0.0
'''